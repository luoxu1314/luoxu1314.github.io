package local.q5.adbrestore;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.util.Log;

final class Restore {
    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("restore", Context.MODE_PRIVATE);
    }
    static boolean enabled(Context c) {
        return prefs(c).getBoolean("enabled", false);
    }
    static void apply(Context c, String reason) {
        if (!enabled(c)) return;
        String status;
        try {
            int before = Settings.Global.getInt(c.getContentResolver(), "adb_enabled", 0);
            boolean ok = before == 1 || Settings.Global.putInt(c.getContentResolver(), "adb_enabled", 1);
            status = reason + ": " + before + " -> "
                + Settings.Global.getInt(c.getContentResolver(), "adb_enabled", 0) + ", success=" + ok;
        } catch (Exception e) {
            status = reason + ": " + e;
        }
        prefs(c).edit().putString("last", status).putLong("time", System.currentTimeMillis()).apply();
        Log.i("Q5AdbRestore", status);
    }
    static void schedule(Context c) {
        JobScheduler jobs = c.getSystemService(JobScheduler.class);
        if (!enabled(c)) return;
        int[] delays = {30000, 90000, 180000};
        for (int i = 0; i < delays.length; i++) {
            jobs.schedule(new JobInfo.Builder(701 + i, new ComponentName(c, RestoreJob.class))
                .setMinimumLatency(delays[i]).setOverrideDeadline(delays[i] + 30000).build());
        }
    }
    static void disable(Context c) {
        prefs(c).edit().putBoolean("enabled", false).commit();
        JobScheduler jobs = c.getSystemService(JobScheduler.class);
        for (int i = 701; i <= 703; i++) jobs.cancel(i);
    }
}
