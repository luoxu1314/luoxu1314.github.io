package local.q5.adbrestore;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class MainActivity extends Activity {
    TextView status;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(64, 40, 64, 40);
        status = new TextView(this);
        status.setTextSize(23);
        layout.addView(status);
        Button enable = new Button(this);
        enable.setText("启用开机恢复并立即恢复 ADB");
        enable.setOnClickListener(v -> {
            Restore.prefs(this).edit().putBoolean("enabled", true).commit();
            Restore.apply(this, "manual enable");
            Restore.schedule(this);
            refresh();
        });
        layout.addView(enable);
        Button disable = new Button(this);
        disable.setText("停用自动恢复（保留当前 ADB 状态）");
        disable.setOnClickListener(v -> { Restore.disable(this); refresh(); });
        layout.addView(disable);
        setContentView(layout);
        refresh();
        enable.requestFocus();
    }
    void refresh() {
        status.setText("ADB 开机恢复\n\n自动恢复：" + (Restore.enabled(this) ? "已启用" : "已停用")
            + "\n当前 ADB 开关：" + Settings.Global.getInt(getContentResolver(), "adb_enabled", 0)
            + "\n上次处理：" + Restore.prefs(this).getString("last", "尚未运行")
            + "\n\n开机完成后恢复 ADB，并在约 30、90、180 秒后复查。\n只更改 ADB 开关；无常驻服务。卸载即可移除自动恢复。\n\n");
    }
}
