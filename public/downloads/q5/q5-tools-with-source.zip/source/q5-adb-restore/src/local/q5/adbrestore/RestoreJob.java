package local.q5.adbrestore;

import android.app.job.JobService;
import android.app.job.JobParameters;

public final class RestoreJob extends JobService {
    @Override public boolean onStartJob(JobParameters p) {
        Restore.apply(this, "boot recheck " + p.getJobId());
        return false;
    }
    @Override public boolean onStopJob(JobParameters p) { return false; }
}
