package local.q5.accessibilitybridge;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public final class BridgeActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Intent target = new Intent("com.cvte.intent.action.ACCESSIBILITY_SETTING");
        target.setComponent(new ComponentName("com.cvte.settings", "com.cvte.settings.Settings$AccessibilitySettings"));
        try {
            startActivity(target);
            Log.i("Q5AccessibilityBridge", "Opened CVTE accessibility settings");
            finish();
        } catch (ActivityNotFoundException | SecurityException e) {
            Log.e("Q5AccessibilityBridge", "Cannot open CVTE accessibility settings", e);
            TextView text = new TextView(this);
            text.setTextSize(26);
            text.setPadding(60, 60, 60, 60);
            text.setText("无法打开本机无障碍设置。\n此入口适用于已验证的小明 Q5 Pro / CVTE 系统。");
            setContentView(text);
        }
    }
}
